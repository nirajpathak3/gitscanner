import React from 'react';
import { useQuery } from '@apollo/client';
import { GET_REPOSITORY_DETAILS } from '../queries';

function RepositoryDetails({ owner, name }) {
    console.log('Repository Details', owner, name);
  const { loading, error, data } = useQuery(GET_REPOSITORY_DETAILS, {
    variables: { owner, name },
  });

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  const { repositoryDetails } = data;

  return (
    <div>
      <h2>Repository Details</h2>
      <p>Name: {repositoryDetails.name}</p>
      <p>Owner: {repositoryDetails.owner}</p>
      <p>Size: {repositoryDetails.size}</p>
      <p>Is Private: {repositoryDetails.isPrivate ? 'Yes' : 'No'}</p>
      <p>Number of Files: {repositoryDetails.numFiles}</p>
      <p>Active Webhooks: {repositoryDetails.activeWebhooks}</p>
      <p>YAML Content: {repositoryDetails.ymlContent}</p>
    </div>
  );
}

export default RepositoryDetails;
